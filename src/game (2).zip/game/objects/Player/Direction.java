package game.objects.Player;

public enum Direction {
    UP, DOWN, LEFT, RIGHT
}
