package game.objects.monsters;

import java.awt.*;

public interface Ghost {
    public void loadImage();
}
